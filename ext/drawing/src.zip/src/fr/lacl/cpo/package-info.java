/**
 * This package contains a simple graphical library which allows to open windows and draw on them.
 */
package fr.lacl.cpo;