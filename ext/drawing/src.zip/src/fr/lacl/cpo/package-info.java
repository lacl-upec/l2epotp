/**
 * This package contains a simple graphical library which allows to open windows and draw on them.
 * 
 * This library distributed is under CC0 1.0 license (http://creativecommons.org/publicdomain/zero/1.0).
 */
package fr.lacl.cpo;