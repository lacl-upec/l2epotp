package fr.lacl.cpo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;
import java.lang.reflect.InvocationTargetException;

import javax.swing.JComponent;
import javax.swing.JFrame;

class DrawingComponent extends JComponent {

  private static final long serialVersionUID = -6136431626953735476L;
  private BufferedImage frontBuffer;
  private BufferedImage backBuffer;
  private float strokeWidth = 1;
  private Color color = Color.BLACK;

  public DrawingComponent(int width, int height) {
    this(width,height,false);
  }
  
  public DrawingComponent(int width, int height,boolean doubleBuffered) {
    frontBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
    if (doubleBuffered)
      backBuffer = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
    else
      backBuffer = null;
  }

  private BufferedImage image() {
    if (backBuffer == null)
      return frontBuffer;
    else
      return backBuffer;
  }
  
  @Override
  public Dimension getPreferredSize() {
    return new Dimension(frontBuffer.getWidth(), frontBuffer.getHeight());
  }

  @Override
  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    BufferedImage image = image();
    g.drawImage(image, (getWidth() - image.getWidth()) / 2,
        (getHeight() - image.getHeight()) / 2, null);
  }

  public void setColor(float red, float green, float blue) {
    this.color = new Color(red, green, blue);
  }

  public void setWidth(float strokeWidth) {
    this.strokeWidth = strokeWidth;
  }

  private Graphics2D graphics() {
    Graphics2D g = (Graphics2D) image().getGraphics();
    g.setColor(color);
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
    return g;
  }

  public void point(double x, double y) {
    Graphics2D g = graphics();
    g.fill(new Ellipse2D.Double(x - strokeWidth / 2, y - strokeWidth / 2,
        strokeWidth, strokeWidth));
    g.dispose();
    if (backBuffer == null)
      doRepaint();
  }

  public void line(double x1, double y1, double x2, double y2) {
    Graphics2D g = graphics();
    g.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND,
        BasicStroke.JOIN_ROUND));
    g.draw(new Line2D.Double(x1, y1, x2, y2));
    g.dispose();
    if (backBuffer == null)
      doRepaint();
  }

  public void clear() {
    Graphics2D g = graphics();
    g.setColor(getBackground());
    g.fillRect(0, 0, frontBuffer.getWidth(), frontBuffer.getHeight());
    g.dispose();
    if (backBuffer == null)
      doRepaint();
  }
  
  public void swap() {
    if (backBuffer == null)
      throw new IllegalStateException("Not back buffered");
    else {
      BufferedImage tmp = backBuffer;
      backBuffer = frontBuffer;
      frontBuffer = tmp;
      doRepaint();
      Graphics g = backBuffer.getGraphics();
      g.setColor(getBackground());
      g.drawImage(frontBuffer, 0, 0, null);
      g.dispose();
    }
  }
  
  private void doRepaint() {
    if (EventQueue.isDispatchThread())
      paintImmediately(0,0,getWidth(),getHeight());
    else {
      try {
        EventQueue.invokeAndWait(repainter);
      } catch (InvocationTargetException | InterruptedException e) {
        throw new IllegalStateException("thread interrupted",e);
      }
    }
  }
  
  private final Runnable repainter = new Runnable() {
    @Override
    public void run() {
      paintImmediately(0,0,getWidth(),getHeight());
    }
  };
}

/**
 * An instance of this class represents a window which can be drawn upon using
 * its methods.
 */
public class Drawing {

  DrawingComponent component;

  /**
   * Creates a new window of specified size and title. Calling this instance's
   * methods allows to draw on the window.
   * 
   * @param title
   *          the title of the window.
   * @param width
   *          the width of the window.
   * @param height
   *          the height of the window.
   */
  public Drawing(String title, int width, int height) {
    this(title,width,height,false);
  }
  
  /**
   * Creates a new window of specified size and title. Calling this instance's
   * methods allows to draw on the window.
   * 
   * @param title
   *          the title of the window.
   * @param width
   *          the width of the window.
   * @param height
   *          the height of the window.
   * @param backBuffered
   *          indicates if the window is back-buffered (see {@link #swap} method).
   */
  public Drawing(String title, int width, int height, boolean backBuffered) {  
    component = new DrawingComponent(width, height, backBuffered);
    JFrame mainFrame = new JFrame();
    mainFrame.setTitle(title);
    mainFrame.add(component);
    mainFrame.pack();
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.setVisible(true);
  }

  /**
   * Sets the color of the pencil.
   * 
   * @param red
   *          the amount of red in [0,1].
   * @param green
   *          the amount of green in [0,1].
   * @param blue
   *          the amount of blue in [0,1].
   */
  public void setColor(double red, double green, double blue) {
    component.setColor((float)red, (float)green, (float)blue);
  }

  /**
   * Sets the line or point thickness.
   * 
   * @param strokeWidth
   *          the thickness.
   */
  public void setWidth(double strokeWidth) {
    component.setWidth((float)strokeWidth);
  }

  /**
   * Draws a point at specified location.
   * 
   * @param x
   *          abscissa of the point to draw.
   * @param y
   *          ordinate of the point to draw.
   */
  public void point(double x, double y) {
    component.point(x, y);
  }

  /**
   * Draws a line between the specified points.
   * 
   * @param x1
   *          abscissa of the first point.
   * @param y1
   *          ordinate of the first point.
   * @param x2
   *          abscissa of the second point.
   * @param y2
   *          ordinate of the second point.
   */
  public void line(double x1, double y1, double x2, double y2) {
    component.line(x1, y1, x2, y2);
  }

  /**
   * Clears the drawing.
   */
  public void clear() {
    component.clear();
  }

  /**
   * Swaps between the back buffer and the front buffer. This makes all the changes made after the last call to the {@code swap} method visible.
   */
  public void swap() {
    component.swap();
  }
  
  

}
