package fr.lacl.cpo;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.image.BufferedImage;

import javax.swing.JComponent;
import javax.swing.JFrame;

class DrawingComponent extends JComponent {

  private static final long serialVersionUID = -6136431626953735476L;
  private final BufferedImage image;
  private float strokeWidth = 1;
  private Color color = Color.BLACK;

  public DrawingComponent(int width, int height) {
    image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
  }

  @Override
  public Dimension getPreferredSize() {
    return new Dimension(image.getWidth(), image.getHeight());
  }

  @Override
  public Dimension getMinimumSize() {
    return getPreferredSize();
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.drawImage(image, (getWidth() - image.getWidth()) / 2,
        (getHeight() - image.getHeight()) / 2, null);
  }

  public void setColor(float red, float green, float blue) {
    this.color = new Color(red, green, blue);
  }

  public void setWidth(float strokeWidth) {
    this.strokeWidth = strokeWidth;
  }

  private Graphics2D graphics() {
    Graphics2D g = (Graphics2D) image.getGraphics();
    g.setColor(color);
    g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
        RenderingHints.VALUE_ANTIALIAS_ON);
    return g;
  }

  public void point(double x, double y) {
    Graphics2D g = graphics();
    g.fill(new Ellipse2D.Double(x - strokeWidth / 2, y - strokeWidth / 2,
        strokeWidth, strokeWidth));
    g.dispose();
    repaint();
  }

  public void line(double x1, double y1, double x2, double y2) {
    Graphics2D g = graphics();
    g.setStroke(new BasicStroke(strokeWidth, BasicStroke.CAP_ROUND,
        BasicStroke.JOIN_ROUND));
    g.draw(new Line2D.Double(x1, y1, x2, y2));
    g.dispose();
    repaint();
  }

  public void clear() {
    Graphics2D g = graphics();
    g.setColor(getBackground());
    g.fillRect(0, 0, image.getWidth(), image.getHeight());
    g.dispose();
    repaint();
  }
}

/**
 * An instance of this class represents a window which can be drawn upon using
 * its methods.
 */
public class Drawing {

  DrawingComponent component;

  /**
   * Creates a new window of specified size and title. Calling this instance's
   * methods allows to draw on the window.
   * 
   * @param title
   *          the title of the window.
   * @param width
   *          the width of the window.
   * @param height
   *          the height of the window.
   */
  public Drawing(String title, int width, int height) {
    component = new DrawingComponent(width, height);
    JFrame mainFrame = new JFrame();
    mainFrame.setTitle(title);
    mainFrame.add(component);
    mainFrame.pack();
    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    mainFrame.setVisible(true);
  }

  /**
   * Sets the color of the pencil.
   * 
   * @param red
   *          the amount of red in [0,1].
   * @param green
   *          the amount of green in [0,1].
   * @param blue
   *          the amount of blue in [0,1].
   */
  public void setColor(float red, float green, float blue) {
    component.setColor(red, green, blue);
  }

  /**
   * Sets the line or point thickness.
   * 
   * @param strokeWidth
   *          the thickness.
   */
  public void setWidth(float strokeWidth) {
    component.setWidth(strokeWidth);
  }

  /**
   * Draws a point at specified location.
   * 
   * @param x
   *          abscissa of the point to draw.
   * @param y
   *          ordinate of the point to draw.
   */
  public void point(double x, double y) {
    component.point(x, y);
  }

  /**
   * Draws a line between the specified points.
   * 
   * @param x1
   *          abscissa of the first point.
   * @param y1
   *          ordinate of the first point.
   * @param x2
   *          abscissa of the second point.
   * @param y2
   *          ordinate of the second point.
   */
  public void line(double x1, double y1, double x2, double y2) {
    component.line(x1, y1, x2, y2);
  }

  /**
   * Clears the drawing.
   */
  public void clear() {
    component.clear();
  }

}
