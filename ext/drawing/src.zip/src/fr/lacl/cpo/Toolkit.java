package fr.lacl.cpo;

/**
 * Simple class with a missing method in Java.
 */
public class Toolkit {

  /**
   * Waits the specified amount of milliseconds and return.
   * 
   * @param millis
   *          the amount of milliseconds to wait.
   */
  public static void sleep(long millis) {
    try {
      Thread.sleep(millis);
    } catch (InterruptedException e) {
      /* TODO */
    }
  }
}
