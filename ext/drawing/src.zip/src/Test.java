import fr.lacl.cpo.Drawing;

public class Test {
  
  static double x(int i) { return 320+100*Math.cos(i*2*Math.PI/5); }
  static double y(int i) { return 240+100*Math.sin(i*2*Math.PI/5); }
  

  public static void main( String[] args) {
      
      Drawing d = new Drawing( "Mon Dessin", 640, 480);

      for (int i = 0; i < 6; i++) {
	  //d.clear();
	  d.setWidth(10);
	  d.line(x(i),y(i),x(i+2),y(i+2));
      }
      
  }

}
