import fr.lacl.cpo.Drawing;

public class Test {

  static double x(double i) {
    return 320 + 100 * Math.cos(i * 2 * Math.PI / 5);
  }

  static double y(double i) {
    return 240 + 100 * Math.sin(i * 2 * Math.PI / 5);
  }

  public static void main(String[] args) {

    Drawing d = new Drawing("Mon Dessin", 640, 480, true);

    double ph;
    for (;;)
      for (ph = 0; ph < 1; ph += 0.02) {
        d.clear();
        for (int i = 0; i < 6; i++) {
          // d.clear();
          d.setWidth(10);
          d.line(x(i+ph), y(i+ph), x(ph+i + 2), y(ph+i + 2));
        }
        d.swap();
      }

  }

}
